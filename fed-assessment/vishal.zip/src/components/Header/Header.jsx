import React from "react";

const Header = () => {
  return (
    <div>
      <h2>Employee</h2>
    </div>
  );
};

export default Header;
