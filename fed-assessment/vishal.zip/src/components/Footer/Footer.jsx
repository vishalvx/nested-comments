import React from "react";

const Footer = () => {
  return (
    <div>
      <h2>&copy; {Date.now()}</h2>
    </div>
  );
};

export default Footer;
