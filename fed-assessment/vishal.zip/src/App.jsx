import { useState } from "react";
import Employee from "./pages/Employee";
import "bootstrap/dist/css/bootstrap.css";
import "./assets/scss/styles.scss";

function App() {
  return (
    <div className="App">
      <Employee />
    </div>
  );
}

export default App;
