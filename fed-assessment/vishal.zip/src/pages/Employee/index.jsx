import React from "react";
import EmployeeProfile from "./EmployeeProfile";
import EmployeeTable from "./EmployeeTable";
const index = () => {
  return (
    <div>
      {/* Employee */}
      {/* <EmployeeTable /> */}
      <EmployeeProfile />
    </div>
  );
};

export default index;
